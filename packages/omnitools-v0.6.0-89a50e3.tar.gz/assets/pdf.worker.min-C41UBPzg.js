const s="/tools/omnitools/assets/pdf.worker.min-r-TJsTTt.mjs";export{s as p};
