const t="/tools/omnitools/assets/grey-pattern-DMumq2xP.png";export{t as g};
